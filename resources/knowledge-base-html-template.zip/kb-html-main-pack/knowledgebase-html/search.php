<ul id="live-search-results" class="clearfix">
        <li class="search-result faq">
                <a href="#">How Is WordPress related to other blogging applications?</a>
        </li>
        <li class="search-result faq">
                <a href="#">What’s the difference between WordPress.org and WordPress.com?</a>
        </li>
        <li class="search-result faq">
                <a href="#">How is WordPress licensed?</a>
        </li>
        <li class="search-result faq">
                <a href="#">When was WordPress first released?</a>
        </li>
        <li class="search-result faq">
                <a href="#">What are WordPress&#8217; features?</a>
        </li>
</ul>